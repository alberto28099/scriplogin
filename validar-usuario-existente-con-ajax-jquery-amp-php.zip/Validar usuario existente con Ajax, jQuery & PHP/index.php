<?php
require_once("DBcontroller.php");
$db_handle = new DBController();
$sql = "SELECT * from usuarios";
$faq = $db_handle->runQuery($sql);
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">
<title>Validar usuario existente con Ajax, jQuery & PHP | BaulPHP</title>

<!-- Bootstrap core CSS -->
<link href="dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Custom styles for this template -->
<link href="assets/sticky-footer-navbar.css" rel="stylesheet">
<style type="text/css">
.username, .email {
	border-top:#F0F0F0 2px solid;
	background:#FAF8F8;
	padding:10px;
}
.demoInputBox {
	padding:7px;
	border:#F0F0F0 1px solid;
	border-radius:4px;
}
.estado-disponible-usuario {
	color:#2FC332;
}
.estado-no-disponible-usuario {
	color:#D60202;
}
.estado-disponible-email {
	color:#2FC332;
}
.estado-no-disponible-email {
	color:#D60202;
}
</style>
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script>
function comprobarUsuario() {
	$("#loaderIcon").show();
	jQuery.ajax({
	url: "ComprobarDisponibilidad.php",
	data:'usuario='+$("#usuario").val(),
	type: "POST",
	success:function(data){
		$("#estadousuario").html(data);
		$("#loaderIcon").hide();
	},
	error:function (){}
	});
}
function comprobarEmail() {
	$("#loaderIconEmail").show();
	jQuery.ajax({
	url: "ComprobarDisponibilidad.php",
	data:'email='+$("#email").val(),
	type: "POST",
	success:function(data){
		$("#estadoemail").html(data);
		$("#loaderIconEmail").hide();
	},
	error:function (){}
	});
}
</script>
</head>

<body>
<header> 
  <!-- Fixed navbar -->
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark"> <a class="navbar-brand" href="#">BaulPHP</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active"> <a class="nav-link" href="index.php">Inicio <span class="sr-only">(current)</span></a> </li>
      </ul>
      <form class="form-inline mt-2 mt-md-0">
        <input class="form-control mr-sm-2" type="text" placeholder="Buscar" aria-label="Search">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Busqueda</button>
      </form>
    </div>
  </nav>
</header>

<!-- Begin page content -->

<div class="container">
  <h3 class="mt-5">Validar usuario existente con Ajax, jQuery & PHP</h3>
  <hr>
  <div class="row">
    <div class="col-12 col-md-12"> 
      <!-- Contenido -->
      
<form>
  <div class="form-group">
    <div class="username">
      <label for="ComprobarUsuario">Comprobar usuario:</label>
      <input name="usuario" type="text" id="usuario" class="form-control" onBlur="comprobarUsuario()">
      <span id="estadousuario"></span> 
      </div>
    <p><img src="LoaderIcon.gif" id="loaderIcon" style="display:none" /></p>
  </div>
  <div class="form-group">
    <div class="email">
      <label for="ComprobarEmail">Comprobar usuario:</label>
      <input name="email" type="text" id="email" class="form-control" onBlur="comprobarEmail()">
      <span id="estadoemail"></span> </div>
    <p><img src="LoaderIcon.gif" id="loaderIconEmail" style="display:none" /></p>
  </div>
</form>
      
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Usuario</th>
      <th scope="col">Email</th>
    </tr>
  </thead>
  <?php
  foreach($faq as $k=>$v) {
  ?>      
  <tbody>
    <tr>
      <th scope="row"><?php echo $k+1; ?></th>
      <td><?php echo $faq[$k]["Usuario"]; ?></td>
      <td><?php echo $faq[$k]["Email"]; ?></td>
    </tr>
  </tbody>
<?php
}
?>
  
</table>


      <!-- Fin Contenido --> 
    </div>
  </div>
  <!-- Fin row --> 
  
</div>
<!-- Fin container -->
<footer class="footer">
  <div class="container"> <span class="text-muted">
    <p>Códigos <a href="https://www.baulphp.com/" target="_blank">BaulPHP</a></p>
    </span> </div>
</footer>

<!-- Bootstrap core JavaScript
    ================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 

<script src="dist/js/bootstrap.min.js"></script>
</body>
</html>